Welcome to Escape! A puzzle game that loops each time you die. If you�re in easy mode the room you�re in will simply reset and 
if you�re in hard mode you will loop back to the start of the game. Also, be careful! You may wonder into a room and find an unexpected surprise�


Controls:

Arrow keys: Movement

R: Restart Room

Escape key: Exit to menu


If you become stuck check out the walkthrough.txt file inside the game's folder.


Everything was created in under 48 hours for Ludum Dare 47.


Creator's note: I consider hard mode the real mode for the game.